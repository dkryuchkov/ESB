SSO MMC Snap-In
Copyright (C) 2008
All rights reserved.


*** Pre-Req's ***

MMC 3.0 must already be installed on your machine.  If you are running Windows 2008 or Windows Vista or newer you already have this.



*** Installation ***

Run setup.exe.  

When walking through the Wizard make sure you enter your company name. 

After the successful installation you can select the SSO Application Configuration.msc shortcut under the SSO Application Configuration item under All Programs.

You can also hit Start -> Run and type MMC on the run line.  When the MMC Console appears you can select File->Add/Remove Snap-In and select the SSO Configuration Store Manager snap-in.

Before you can run the Snap-In you must be added to the SSO Administrators AD Group that was created when the SSO Server was installed.




*** Functionality ***

The SSO MMC Snap-In provides the following functions.  You will have the ability to:

1.  Create configuration applications.
	To create an application right click on the root node.  Click on the Add Application menu item when the popup menu appears.  A default name will be added to the tree view.  To change the application name, right click on the application node and select Rename on the popup menu. 

2.  Create key/value pairs within an application.
	To create a key value pair right click on the application node and select Add Key Value Pair from the popup menu.  When the Add Key/Value Pair dialog appears enter your key and value and hit OK.  Add as many configuration key/value pairs as you will need for this application.

3.  Manage (modify and delete) existing key/value pairs.
	To modify an existing key/value pair, select the application and click on the key/value pair in the middle pane.  Under the actions pane on the right hand side you will see a section for the key with a Properties and Delete menu item.  Select Properties and the Key/Value Properties dialog box will appear.  Make your changes and click OK.

	You can also right click on the key/value in the middle pane and a popup menu will appear.  Select Properties to access the dialog box.

	To delete a key/value pair, select the application and click on the key/value pair in the middle pane.  Under the actions pane on the right hand side you will see a section for the key with a Properties and Delete menu item.  Select the Delete menu item.  

	You can also right click on the key/value in the middle pane and a popup menu will appear.  Select the Delete menu item.
	

4.  Export Configuration Application
	To export an application, right click the application you wish to export.  Click on the Export Application menu item.  The Enter Key for Export dialog will appear.  Type in an encryption key.

	This key is used to encrypt the configuration data that is written to the hard drive.  You MUST use this same key when you import this application. 

	Provide an application name.  This name is used to create an application of this name when doing an import.  What this means is that if you export application X and provide name Y (or go to the file system and change the name), when you import the application you will have a new application with the name Y.

	In addition, if you add key/value pairs to an application and you wish to export the new values, export the application and when you import only the new key/values will be imported.  It is important to note that if existing values are changed then you will need to open the snap-in in the other environment and make those changes manually.  This was done intentionally because there are times that the same keys will have different values for different environments.

5.  Import Configuration Application
	To import an application, right click on the root node and click on the Import Application menu item.

	Select the application you exported that you  now wish to import and click Open on the Import SSO Application dialog.  You will then be prompted with the Enter Key For Import dialog box.  You will need to enter the same key that was used when the application was exported.  If the application was new for this environment you will see a new application in the application tree.  If this application already existed you will see new key/pairs added to the existing application.

6.  See all errors entered in the Application Event Log.




*** Known Issues ***

1.  If you are running Windows 2003 server or Windows XP or earlier then you may not have MMC 3.0.  You may also receive an error that an exception occured durin ghte install phase.  Install MMC 3.0.  Also, you may need to GAC the ManagementConsole dll's.  To do this, run the MMCPerf.exe tool in the System32 directory to install these files in the GAC.


2.  You see that the snap-in says you don't have access rights.  You will need to be added to the SSO Administrators AD Group that was created when the SSO Server was installed. 